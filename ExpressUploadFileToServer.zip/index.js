const express   = require('express');
const app       = express();
const port      = 5020;

// Require the upload middleware
const uploadFile = require("./upload")

// Set up a route for file uploads
app.post('/upload', async (req, res) => {

    try {
        await uploadFile(req, res, function(err) {
            if(err) {
                res.status(500).json({
                    status_code: 403,
                    status: 'Request Forbidden',
                    message: `Could not upload the file. ${err}`,
                    data: null
                });
            } else {
                let result = []
                for (let index = 0; index < req.files.length; index++) {
                    result.push({
                        url: req.files[index]["filename"]
                    })
                }

                res.status(200).json({
                    status_code: 200,
                    status: 'success',
                    message: "Uploaded the file successfully: ",
                    data: result
                });
            }
        });

        if (req.file == undefined) {
            return res.status(400).send({ message: "Please upload a file!" });
        }

    } catch (err) {
        res.status(500).json({
            status_code: 500,
            status: 'Internal Server Error',
            message: `Could not upload the file. Please contact our support system.`,
            data: null
        });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});