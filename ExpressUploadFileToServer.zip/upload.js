const util      = require("util");
const multer    = require("multer");
const maxSize   = 5 * 1024 * 1024;

let storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads");
    },
    filename: (req, file, cb) => {
        console.log(file.originalname);
        cb(null, new Date().getTime() + '__file.' + file.originalname);
    },
});

let uploadFile = multer({
  storage: storage,
  limits: { fileSize: maxSize }
}).array("file", 5)

let uploadFileMiddleware = util.promisify(uploadFile);
module.exports = uploadFileMiddleware;